package EmpClass;
public class Employee
{
	String Name;
	Int Salary;
	Int Age;
	
	
	
	
}