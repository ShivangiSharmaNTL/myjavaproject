package com.servlet.example;

import org.junit.*;

public class Unitprt {

	@Test
	public void test() {
		
	}

}
