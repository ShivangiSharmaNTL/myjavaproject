
public class Emp {
String Name;
String Email;
String MobileNo;
String DOB;

void setName(String s)
{
	this.Name = s;

}

void setMobileNo(String s)
{
	this. MobileNo = s;

}

void setEmail(String s)
{
	this.Email = s;

}

void setDOB(String s)
{
	this.DOB = s;

}
}
